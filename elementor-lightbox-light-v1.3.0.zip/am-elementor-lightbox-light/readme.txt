=== Elementor Lightbox Device Controls — Light ===
Contributors: custom
Tags: elementor, lightbox, mobile, tablet
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.3.0

Disabilita completamente il lightbox di Elementor su Mobile e/o Tablet.
Nessuna opzione aggiuntiva. Plug & play.

Opzioni in Site Settings > Lightbox:
- Disabilita Lightbox su Mobile
- Disabilita Lightbox su Tablet
