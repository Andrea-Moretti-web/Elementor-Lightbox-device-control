<?php
/**
 * Plugin Name: Elementor Lightbox Device Controls — Light
 * Description: Disabilita completamente il lightbox di Elementor su Mobile e Tablet. Nessuna opzione aggiuntiva, plug & play.
 * Version: 1.3.0
 * Author: Custom
 * Text Domain: am-el-lightbox-light
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class AM_EL_Lightbox_Light {

    const VERSION       = '1.3.0';
    const SCRIPT_HANDLE = 'am-el-lightbox-light';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', array( $this, 'init' ) );
    }

    public function init() {
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', array( $this, 'admin_notice_missing_elementor' ) );
            return;
        }

        // Aggiunge i due toggle in Site Settings > Lightbox
        add_action(
            'elementor/element/kit/section_settings-lightbox/before_section_end',
            array( $this, 'register_controls' ),
            10,
            2
        );

        add_action( 'elementor/frontend/after_enqueue_scripts', array( $this, 'enqueue_script' ) );
        add_action( 'elementor/preview/enqueue_scripts',        array( $this, 'enqueue_script' ) );
    }

    public function admin_notice_missing_elementor() {
        if ( ! current_user_can( 'activate_plugins' ) ) return;
        echo '<div class="notice notice-warning"><p>';
        echo esc_html__( 'Elementor Lightbox Light richiede Elementor installato e attivo.', 'am-el-lightbox-light' );
        echo '</p></div>';
    }

    public function register_controls( $element, $args ) {
        if ( ! class_exists( '\Elementor\Controls_Manager' ) ) return;

        $element->add_control(
            'am_el_lb_light_heading',
            array(
                'type'      => \Elementor\Controls_Manager::HEADING,
                'label'     => esc_html__( 'Disabilita Lightbox per Device', 'am-el-lightbox-light' ),
                'separator' => 'before',
            )
        );

        $element->add_control(
            'am_el_lb_light_disable_mobile',
            array(
                'label'              => esc_html__( 'Disabilita Lightbox su Mobile', 'am-el-lightbox-light' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
            )
        );

        $element->add_control(
            'am_el_lb_light_disable_tablet',
            array(
                'label'              => esc_html__( 'Disabilita Lightbox su Tablet', 'am-el-lightbox-light' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
            )
        );
    }

    private function bool_setting( $settings, $key ) {
        return ( isset( $settings[ $key ] ) && 'yes' === $settings[ $key ] );
    }

    public function enqueue_script() {
        $settings = array(
            'disable_mobile' => false,
            'disable_tablet' => false,
        );

        try {
            $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();
            $s   = $kit ? $kit->get_settings() : array();
            $settings['disable_mobile'] = $this->bool_setting( $s, 'am_el_lb_light_disable_mobile' );
            $settings['disable_tablet'] = $this->bool_setting( $s, 'am_el_lb_light_disable_tablet' );
        } catch ( \Throwable $e ) {}

        wp_register_script(
            self::SCRIPT_HANDLE,
            plugin_dir_url( __FILE__ ) . 'assets/frontend.js',
            array( 'jquery', 'elementor-frontend' ),
            self::VERSION,
            true
        );

        wp_localize_script( self::SCRIPT_HANDLE, 'AMElLbLight', $settings );
        wp_enqueue_script( self::SCRIPT_HANDLE );
    }
}

AM_EL_Lightbox_Light::instance();
