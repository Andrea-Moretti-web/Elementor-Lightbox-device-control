(function ($) {
  "use strict";

  var cfg = window.AMElLbLight || {};

  var state = {
    listenerInstalled: false,
    observerInstalled: false,
    scheduled: false,
    active: false
  };

  /* ─────────────────────────────────────────────
     Rileva il device corrente via matchMedia
     (le classi Elementor sul body esistono solo
      nell'editor preview, non sul frontend reale)
  ───────────────────────────────────────────── */
  function shouldDisable() {
    if (cfg.disable_mobile && window.matchMedia("(max-width: 767px)").matches)  return true;
    if (cfg.disable_tablet && window.matchMedia("(max-width: 1024px)").matches) return true;
    return false;
  }

  /* ─────────────────────────────────────────────
     Neutralizza TUTTI gli elementi con lightbox
     attivo (qualsiasi valore diverso da "no"):
     salva il valore originale in data-am-lb
     così da poterlo ripristinare se serve.
  ───────────────────────────────────────────── */
  function disableLightboxInDOM() {
    // Attributo lightbox su trigger diretti
    document.querySelectorAll("[data-elementor-open-lightbox]:not([data-elementor-open-lightbox='no'])").forEach(function (el) {
      if (!el.hasAttribute("data-am-lb")) {
        el.setAttribute("data-am-lb", el.getAttribute("data-elementor-open-lightbox"));
      }
      el.setAttribute("data-elementor-open-lightbox", "no");
    });

    // Link <a> che puntano direttamente a file immagine (gallerie, image widget)
    // Rimuovere l'href è il modo più sicuro per bloccare l'apertura diretta del file
    document.querySelectorAll(".elementor a[href]").forEach(function (a) {
      var href = a.getAttribute("href") || "";
      if (/\.(?:jpe?g|png|gif|webp|svg|avif)(?:\?.*)?(?:#.*)?$/i.test(href)) {
        if (!a.hasAttribute("data-am-href")) {
          a.setAttribute("data-am-href", href);
        }
        a.removeAttribute("href");
        a.style.cursor = "default";
      }
    });
  }

  /* ─────────────────────────────────────────────
     Ripristina i valori originali
     (usato se il device torna a desktop)
  ───────────────────────────────────────────── */
  function restoreLightboxInDOM() {
    document.querySelectorAll("[data-am-lb]").forEach(function (el) {
      el.setAttribute("data-elementor-open-lightbox", el.getAttribute("data-am-lb"));
      el.removeAttribute("data-am-lb");
    });
    document.querySelectorAll("a[data-am-href]").forEach(function (a) {
      a.setAttribute("href", a.getAttribute("data-am-href"));
      a.removeAttribute("data-am-href");
      a.style.cursor = "";
    });
  }

  /* ─────────────────────────────────────────────
     Applicazione principale
  ───────────────────────────────────────────── */
  function applyOnce() {
    var active = shouldDisable();
    state.active = active;
    if (active) {
      disableLightboxInDOM();
    } else {
      restoreLightboxInDOM();
    }
  }

  function scheduleApply() {
    if (state.scheduled) return;
    state.scheduled = true;
    (window.requestAnimationFrame || function (fn) { setTimeout(fn, 16); })(function () {
      state.scheduled = false;
      applyOnce();
    });
  }

  /* ─────────────────────────────────────────────
     Click blocker — secondo livello di difesa
     Blocca qualsiasi click su trigger lightbox
     ancora attivi (es. widget renderizzati dopo
     l'ultimo applyOnce)
  ───────────────────────────────────────────── */
  function installClickBlocker() {
    if (state.listenerInstalled) return;
    state.listenerInstalled = true;

    document.addEventListener("click", function (e) {
      if (!state.active) return;
      var target = e.target;
      if (!target || !target.closest) return;

      // Trigger con lightbox ancora attivo
      var lbEl = target.closest("[data-elementor-open-lightbox]:not([data-elementor-open-lightbox='no'])");
      if (lbEl) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        return;
      }

      // Link diretto a file immagine (per sicurezza)
      var a = target.closest("a[href]");
      if (a && /\.(?:jpe?g|png|gif|webp|svg|avif)(?:\?.*)?(?:#.*)?$/i.test(a.getAttribute("href") || "")) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    }, true); // capture phase
  }

  /* ─────────────────────────────────────────────
     MutationObserver per widget dinamici/lazy
     Solo scheduleApply — nessuna reinstallazione
     di listener
  ───────────────────────────────────────────── */
  function installObserver() {
    if (state.observerInstalled || !window.MutationObserver) return;
    state.observerInstalled = true;
    new MutationObserver(function () {
      scheduleApply();
    }).observe(document.body, { childList: true, subtree: true });
  }

  /* ─────────────────────────────────────────────
     Boot — eseguito al DOMContentLoaded,
     prima che Elementor inizializzi i suoi handler
  ───────────────────────────────────────────── */
  function boot() {
    applyOnce();
    installClickBlocker();
    window.addEventListener("resize",            scheduleApply, { passive: true });
    window.addEventListener("orientationchange", scheduleApply, { passive: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  // Dopo init Elementor: cattura widget lazy e avvia l'observer
  $(window).on("elementor/frontend/init", function () {
    scheduleApply();
    installObserver();
  });

})(jQuery);
