<?php
/**
 * Plugin Name: Elementor Lightbox Device Controls (Site Settings)
 * Description: Adds extra controls to Elementor Site Settings > Lightbox to disable the lightbox and/or block image (media file) links on mobile/tablet or below a custom breakpoint.
 * Version: 1.3.0
 * Author: Custom
 * Text Domain: am-el-lightbox-device-controls
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class AM_EL_Lightbox_Device_Controls {

    const VERSION = '1.3.0';
    const SCRIPT_HANDLE = 'am-el-lightbox-device-controls';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', array( $this, 'init' ) );
    }

    public function init() {
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', array( $this, 'admin_notice_missing_elementor' ) );
            return;
        }

        // Add controls into: Site Settings > Lightbox
        add_action(
            'elementor/element/kit/section_settings-lightbox/before_section_end',
            array( $this, 'register_site_settings_controls' ),
            10,
            2
        );

        // Frontend + Preview
        add_action( 'elementor/frontend/after_enqueue_scripts', array( $this, 'enqueue_frontend_script' ) );
        add_action( 'elementor/preview/enqueue_scripts', array( $this, 'enqueue_frontend_script' ) );
    }

    public function admin_notice_missing_elementor() {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        echo '<div class="notice notice-warning"><p>';
        echo esc_html__( 'Elementor Lightbox Device Controls requires Elementor to be installed and activated.', 'am-el-lightbox-device-controls' );
        echo '</p></div>';
    }

    public function register_site_settings_controls( $element, $args ) {
        if ( ! class_exists( '\Elementor\Controls_Manager' ) ) {
            return;
        }

        $element->add_control(
            'am_el_lb_device_controls_heading',
            array(
                'type'      => \Elementor\Controls_Manager::HEADING,
                'label'     => esc_html__( 'Device / Breakpoint Controls (extra)', 'am-el-lightbox-device-controls' ),
                'separator' => 'before',
            )
        );

        $element->add_control(
            'am_el_lb_use_custom_breakpoint',
            array(
                'label'              => esc_html__( 'Use custom breakpoint (instead of Mobile/Tablet)', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
            )
        );

        $element->add_control(
            'am_el_lb_custom_breakpoint_px',
            array(
                'label'              => esc_html__( 'Custom breakpoint (px)', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::NUMBER,
                'min'                => 320,
                'max'                => 3000,
                'step'               => 1,
                'default'            => 1024,
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint' => 'yes',
                ),
                'description'        => esc_html__( 'Applies the rules when viewport width is <= this value.', 'am-el-lightbox-device-controls' ),
            )
        );

        // Per-device toggles (used when custom breakpoint is OFF)
        $element->add_control(
            'am_el_lb_disable_lightbox_mobile',
            array(
                'label'              => esc_html__( 'Disable Lightbox on Mobile', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint!' => 'yes',
                ),
            )
        );

        $element->add_control(
            'am_el_lb_disable_lightbox_tablet',
            array(
                'label'              => esc_html__( 'Disable Lightbox on Tablet', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint!' => 'yes',
                ),
            )
        );

        $element->add_control(
            'am_el_lb_block_image_links_mobile',
            array(
                'label'              => esc_html__( 'Block ONLY Media File links on Mobile (allow custom URLs)', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint!' => 'yes',
                ),
                'description'        => esc_html__( 'Prevents navigation to image files (jpg/png/webp/etc). If an image has a custom URL, it will still work.', 'am-el-lightbox-device-controls' ),
            )
        );

        $element->add_control(
            'am_el_lb_block_image_links_tablet',
            array(
                'label'              => esc_html__( 'Block ONLY Media File links on Tablet (allow custom URLs)', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint!' => 'yes',
                ),
            )
        );

        // Breakpoint-mode toggles (used when custom breakpoint is ON)
        $element->add_control(
            'am_el_lb_bp_disable_lightbox',
            array(
                'label'              => esc_html__( 'Disable Lightbox below breakpoint', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => 'yes',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint' => 'yes',
                ),
            )
        );

        $element->add_control(
            'am_el_lb_bp_block_image_links',
            array(
                'label'              => esc_html__( 'Block ONLY Media File links below breakpoint (allow custom URLs)', 'am-el-lightbox-device-controls' ),
                'type'               => \Elementor\Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => 'yes',
                'frontend_available' => true,
                'condition'          => array(
                    'am_el_lb_use_custom_breakpoint' => 'yes',
                ),
                'description'        => esc_html__( 'If an image links to a media file (jpg/png/webp/etc), the click will be blocked. If it links to a custom URL, it will still open.', 'am-el-lightbox-device-controls' ),
            )
        );
    }

    private function bool_setting( $settings, $key ) {
        return ( isset( $settings[ $key ] ) && 'yes' === $settings[ $key ] );
    }

    private function int_setting( $settings, $key, $default ) {
        if ( isset( $settings[ $key ] ) ) {
            $v = intval( $settings[ $key ] );
            if ( $v > 0 ) return $v;
        }
        return $default;
    }

    private function get_frontend_settings() {
        $defaults = array(
            'use_custom_breakpoint' => false,
            'custom_breakpoint_px'  => 1024,

            // device mode
            'disable_lightbox_mobile' => false,
            'disable_lightbox_tablet' => false,
            'block_links_mobile'      => false,
            'block_links_tablet'      => false,

            // breakpoint mode
            'bp_disable_lightbox' => true,
            'bp_block_links'      => true,
        );

        try {
            $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();
            $settings = $kit ? $kit->get_settings() : array();
        } catch ( \Throwable $e ) {
            $settings = array();
        }

        $defaults['use_custom_breakpoint'] = $this->bool_setting( $settings, 'am_el_lb_use_custom_breakpoint' );
        $defaults['custom_breakpoint_px']  = $this->int_setting( $settings, 'am_el_lb_custom_breakpoint_px', 1024 );

        $defaults['disable_lightbox_mobile'] = $this->bool_setting( $settings, 'am_el_lb_disable_lightbox_mobile' );
        $defaults['disable_lightbox_tablet'] = $this->bool_setting( $settings, 'am_el_lb_disable_lightbox_tablet' );
        $defaults['block_links_mobile']      = $this->bool_setting( $settings, 'am_el_lb_block_image_links_mobile' );
        $defaults['block_links_tablet']      = $this->bool_setting( $settings, 'am_el_lb_block_image_links_tablet' );

        $defaults['bp_disable_lightbox'] = $this->bool_setting( $settings, 'am_el_lb_bp_disable_lightbox' );
        $defaults['bp_block_links']      = $this->bool_setting( $settings, 'am_el_lb_bp_block_image_links' );

        return $defaults;
    }

    public function enqueue_frontend_script() {
        $src = plugin_dir_url( __FILE__ ) . 'assets/frontend.js';

        wp_register_script(
            self::SCRIPT_HANDLE,
            $src,
            array( 'jquery', 'elementor-frontend' ),
            self::VERSION,
            true
        );

        wp_localize_script(
            self::SCRIPT_HANDLE,
            'AMElLbDeviceControls',
            $this->get_frontend_settings()
        );

        wp_enqueue_script( self::SCRIPT_HANDLE );
    }
}

AM_EL_Lightbox_Device_Controls::instance();
