=== Elementor Lightbox Device Controls (Site Settings) ===
Contributors: custom
Tags: elementor, lightbox, mobile, tablet, breakpoint
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.3.0

Adds extra toggles into Elementor -> Site Settings -> Lightbox.

Custom Breakpoint mode:
- Use custom breakpoint (instead of Mobile/Tablet)
- Custom breakpoint (px)
- Disable Lightbox below breakpoint
- Block ONLY Media File links below breakpoint (allow custom URLs)

Device mode:
- Disable Lightbox on Mobile/Tablet
- Block ONLY Media File links on Mobile/Tablet (allow custom URLs)

Behavior
- The plugin disables Elementor lightbox handlers when enabled.
- It blocks navigation ONLY if the href is an image file (jpg/png/webp/etc) AND the "Block Media File links" option is enabled.
- Custom URLs keep working.
