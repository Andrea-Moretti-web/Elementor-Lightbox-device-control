(function ($) {
  "use strict";

  var cfg = window.AMElLbDeviceControls || {};

  /* ─────────────────────────────────────────────
     Stato globale — evita listener/observer duplicati
  ───────────────────────────────────────────── */
  var state = {
    listenerInstalled: false,
    observerInstalled: false,
    scheduled: false,
    lastFlags: null
  };

  /* ─────────────────────────────────────────────
     Utility
  ───────────────────────────────────────────── */
  function isImageUrl(href) {
    if (!href || typeof href !== "string") return false;
    if (/^(#|mailto:|tel:|javascript:)/i.test(href)) return false;
    return /\.(?:jpe?g|png|gif|webp|svg|avif)(?:\?.*)?(?:#.*)?$/i.test(href);
  }

  function getDevice() {
    if (window.matchMedia("(max-width: 767px)").matches)  return "mobile";
    if (window.matchMedia("(max-width: 1024px)").matches) return "tablet";
    return "desktop";
  }

  function viewportBelowBreakpoint() {
    var bp = parseInt(cfg.custom_breakpoint_px, 10);
    if (!bp || bp < 1) bp = 1024;
    return window.matchMedia("(max-width: " + bp + "px)").matches;
  }

  /* ─────────────────────────────────────────────
     Calcolo flags in base alla configurazione
  ───────────────────────────────────────────── */
  function getFlags() {
    if (cfg.use_custom_breakpoint) {
      var below = viewportBelowBreakpoint();
      return {
        active:         below,
        disableLightbox: below && !!cfg.bp_disable_lightbox,
        blockLinks:      below && !!cfg.bp_block_links
      };
    }
    var device = getDevice();
    if (device === "mobile") {
      return {
        active:         !!cfg.disable_lightbox_mobile || !!cfg.block_links_mobile,
        disableLightbox: !!cfg.disable_lightbox_mobile,
        blockLinks:      !!cfg.block_links_mobile
      };
    }
    if (device === "tablet") {
      return {
        active:         !!cfg.disable_lightbox_tablet || !!cfg.block_links_tablet,
        disableLightbox: !!cfg.disable_lightbox_tablet,
        blockLinks:      !!cfg.block_links_tablet
      };
    }
    return { active: false, disableLightbox: false, blockLinks: false };
  }

  /* ─────────────────────────────────────────────
     1. Neutralizza attributi lightbox nel DOM
        Copre: "yes", "default" e qualsiasi altro
        valore che non sia già "no".
  ───────────────────────────────────────────── */
  function neutralizeLightboxTriggers() {
    document.querySelectorAll("[data-elementor-open-lightbox]").forEach(function (el) {
      var cur = el.getAttribute("data-elementor-open-lightbox");
      if (!cur || cur === "no") return;
      if (!el.hasAttribute("data-am-open-lightbox")) {
        el.setAttribute("data-am-open-lightbox", cur);
      }
      el.setAttribute("data-elementor-open-lightbox", "no");
    });
  }

  /* ─────────────────────────────────────────────
     2. Blocca i link diretti a file media
        FIX 1.2.3: cerca l'<a> sia come antenato
        (image widget: <a><img/></a>) sia come
        discendente (gallerie: <div><a><img/></a></div>).
  ───────────────────────────────────────────── */
  function findAnchor(el) {
    if (!el) return null;
    // Caso A — l'elemento è dentro un <a> (image widget, link box)
    var up = el.closest ? el.closest("a[href]") : null;
    if (up) return up;
    // Caso B — l'elemento contiene un <a> (galleria: il trigger è il wrapper)
    var down = el.querySelector ? el.querySelector("a[href]") : null;
    return down || null;
  }

  function blockMediaFileHrefs() {
    // Seleziona sia i trigger già neutralizzati (data-am-open-lightbox)
    // sia quelli ancora attivi (data-elementor-open-lightbox != "no")
    var sel = "[data-am-open-lightbox], [data-elementor-open-lightbox]:not([data-elementor-open-lightbox='no'])";
    document.querySelectorAll(sel).forEach(function (el) {
      var a = findAnchor(el);
      if (!a) return;
      var href = a.getAttribute("href") || "";
      if (!href || !isImageUrl(href)) return;
      if (!a.hasAttribute("data-am-href")) {
        a.setAttribute("data-am-href", href);
      }
      a.removeAttribute("href");
      a.style.cursor = "default";
    });
  }

  /* ─────────────────────────────────────────────
     3. Ripristina i valori originali
        (usato quando si torna a desktop dopo un resize)
  ───────────────────────────────────────────── */
  function restoreOriginalValues() {
    document.querySelectorAll("[data-am-open-lightbox]").forEach(function (el) {
      var orig = el.getAttribute("data-am-open-lightbox");
      if (orig) {
        el.setAttribute("data-elementor-open-lightbox", orig);
      } else {
        el.removeAttribute("data-elementor-open-lightbox");
      }
      el.removeAttribute("data-am-open-lightbox");
    });
    document.querySelectorAll("a[data-am-href]").forEach(function (a) {
      var href = a.getAttribute("data-am-href");
      if (href) a.setAttribute("href", href);
      a.removeAttribute("data-am-href");
      a.style.cursor = "";
    });
  }

  /* ─────────────────────────────────────────────
     applyOnce — orchestratore principale
  ───────────────────────────────────────────── */
  function applyOnce() {
    var flags = getFlags();
    state.lastFlags = flags;

    if (!flags.active) {
      restoreOriginalValues();
      return;
    }
    if (flags.disableLightbox) neutralizeLightboxTriggers();
    if (flags.blockLinks)      blockMediaFileHrefs();
  }

  function scheduleApply() {
    if (state.scheduled) return;
    state.scheduled = true;
    (window.requestAnimationFrame || function (fn) { setTimeout(fn, 16); })(function () {
      state.scheduled = false;
      applyOnce();
    });
  }

  /* ─────────────────────────────────────────────
     4. Click blocker — secondo livello di difesa
        FIX 1.2.3: per blockLinks non controlla
        data-elementor-open-lightbox sull'<a>
        (che è spesso vuoto), ma cerca il wrapper
        genitore con quell'attributo.
  ───────────────────────────────────────────── */
  function installClickBlocker() {
    if (state.listenerInstalled) return;
    state.listenerInstalled = true;

    document.addEventListener("click", function (e) {
      var flags = state.lastFlags || getFlags();
      if (!flags.active) return;

      var target = e.target;
      if (!target || !target.closest) return;

      // — Blocco lightbox: qualsiasi trigger con valore != "no"
      if (flags.disableLightbox) {
        var lbEl = target.closest("[data-elementor-open-lightbox]");
        if (lbEl) {
          var val = lbEl.getAttribute("data-elementor-open-lightbox");
          if (val && val !== "no") {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return;
          }
        }
      }

      // — Blocco link media: cerca l'<a> (sia sopra che sotto il target)
      //   poi verifica se appartiene a un contesto Elementor lightbox
      if (flags.blockLinks) {
        // Direzione 1: il target è dentro un <a>
        var a = target.closest("a");
        // Direzione 2: se non trovato, il target è un wrapper con <a> dentro
        if (!a && target.querySelector) a = target.querySelector("a");

        if (a) {
          var href = a.getAttribute("href") || a.getAttribute("data-am-href") || "";
          if (href && isImageUrl(href)) {
            // Blocca solo se siamo in un contesto lightbox Elementor
            var lbCtx = a.closest("[data-elementor-open-lightbox], [data-am-open-lightbox]") ||
                        a.querySelector("[data-elementor-open-lightbox], [data-am-open-lightbox]");
            if (lbCtx) {
              e.preventDefault();
              e.stopPropagation();
              e.stopImmediatePropagation();
            }
          }
        }
      }
    }, true); // capture phase — prima degli handler di Elementor
  }

  /* ─────────────────────────────────────────────
     5. MutationObserver — widget lazy/dinamici
        Solo scheduleApply, NON reinstalla listener
  ───────────────────────────────────────────── */
  function installObserver() {
    if (state.observerInstalled || !window.MutationObserver) return;
    state.observerInstalled = true;
    new MutationObserver(function () {
      scheduleApply();
    }).observe(document.body, { childList: true, subtree: true });
  }

  /* ─────────────────────────────────────────────
     Boot
  ───────────────────────────────────────────── */
  function boot() {
    applyOnce();
    installClickBlocker();
    window.addEventListener("resize",            scheduleApply, { passive: true });
    window.addEventListener("orientationchange", scheduleApply, { passive: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  // Dopo init Elementor: cattura widget renderizzati in ritardo e avvia observer
  $(window).on("elementor/frontend/init", function () {
    scheduleApply();
    installObserver();
  });

})(jQuery);
